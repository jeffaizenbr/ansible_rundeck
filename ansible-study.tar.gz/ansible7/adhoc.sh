#!/bin/bash



ansible all -m yum_repository -a "name=EPEL description=RHEL8 baseurl=https://epelrepo.com enabled=false  gpgcheck=true gpgkey=https://keyhttps.com" -b 
