#!/bin/bash

ansible all -m yum_repository -a "name=EPEL description=RHEL8 baseurl=http://epel.com.br gpgcheck=true gpgkey=http:://gpg_key enabled=false" -b 
