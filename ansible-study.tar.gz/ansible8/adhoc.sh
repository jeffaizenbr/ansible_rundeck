#!/bin/bash


ansible all -m raw -a 'dnf install -y https://dl.fedoraproject.org/pub/epel/epel-release-latest-8.noarch.rpm' -b 

ansible all -m raw -a  'dnf install python36 lvm2 vim -y' -b

ansible all -m user -a 'name=sandy group=wheel state=present' -b

ansible all -m lineinfile -a "path=/etc/sudoers line='sandy ALL=(ALL) NOPASSWD: ALL' state=present" -b

ansible all -m yum_repository -a "name=EPEL description=RHEL8 baseurl=https://dl.fedora gpgcheck=false enabled=false" -b

ansible all -m yum_repository -a "name=EPEL2 description=rhel8 baseurl=https://epel  gpgcheck=true gpgkey=https://epel-key enabled=false" -b
