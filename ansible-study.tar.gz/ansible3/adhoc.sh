#!/bin/bash
ansible all -m yum_repository -a "name=EPEL description=RHEL8 baseurl=https://epel gpgcheck=true gpgkey=https://epel_key enabled=false" -b
