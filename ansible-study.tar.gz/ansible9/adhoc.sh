#!/bin/bash


ansible all -m raw -a "dnf install -y https://dl.fedoraproject.org/pub/epel/epel-release-latest-8.noarch.rpm" -b 

ansible all -m raw -a "dnf install lvm2  python36 -y" -b 

ansible all -m yum_repository -a "name=EPEL description=RHEL8 baseurl=https://epel.com/repo gpgcheck=true gpgkey=https://epel.com/key enabled=false" -b

