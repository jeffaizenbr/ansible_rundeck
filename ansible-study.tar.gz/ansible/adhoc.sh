#!/bin/bash

ansible all -m yum_repository -a "name=EPEL description=RHEL8 baseurl=http://epel-fedora.org enabled=false gpgcheck=false" -b 

ansible all -m yum_repository -a "name=EPEL description=RHEL8 baseurl=http://epel-fedora.org enabled=false gpgcheck=true gpgkey=httpd:///epel-key" -b 
