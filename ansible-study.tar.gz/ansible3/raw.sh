#!/bin/bash

ansible all -m raw -a "dnf install -y https://dl.fedoraproject.org/pub/epel/epel-release-latest-8.noarch.rpm"

ansible all -m raw -a "dnf install python36 vim lvm2 -y "
