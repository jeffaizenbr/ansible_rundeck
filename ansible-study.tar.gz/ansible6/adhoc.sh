#!/bin/bash



ansible all -m yum_repository -a "name='rhel8' baseurl=https://epel-repo description=EPEL gpgcheck=true gpgkey=https://key enabled=false" -b 
